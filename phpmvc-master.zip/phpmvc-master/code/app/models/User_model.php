<?php 

class User_model {
    private $nama = 'Doddy Ferdiansyah';

    public function getUser()
    {
        return $this->nama;
    }
}