<?php 
	// STANDAR OUTPUT
	// echo dan print
	// echo "Jum'at";

	// PENULISAN PHP
	// PHP di dalam HTML
	// HTML di dalam PHP

	// VARIABEL
	// diawali dengan tanda $
	// nama variabel tidak boleh diawali dengan angka
	// boleh mengandung angka
	// $nama = "Sandhika Galih";
	// $pesan = "Halo, selamat datang $nama";

	// OPERATOR
	// Aritmatika
	// + - * / %
	// $a = 10;
	// $b = 20;
	// echo $a + $b;

	// CONCATENATION / CONCAT / PENGGABUNG STRING
	// .
	// $nama_depan = "Sandhika";
	// $nama_belakang = "Galih";
	// echo $nama_depan . " " . $nama_belakang;

	// ASSIGNMENT / PENUGASAN
	// =, +=, -=, *=, /=, %=, .=
	// $x = "Sandhika";
	// $x .= " ";
	// $x .= "Galih";
	// echo $x;

	// PERBANDINGAN / COMPARATION
	// ==, <=, >=, <, >, !=

	// IDENTITAS / STRICT COMPARATION
	// ===, !==

	// LOGIKA / LOGICAL
	// &&, ||, !




?>