<?php
// deklarasi array
// php 4
$array1 = array(5, 10, 12, 20, 35);

// php 5
$hari = ["senin", "selasa", "rabu"];
$array2 = ["tulisan", 100, false];

// Mencetak Isi Array (untuk debug)
// 1. print_r
print_r($array1);
echo "<br>";
// 2. var_dump
var_dump($hari);
echo "<br>";
// 3. echo, elemen array nya
echo $array1[2];
echo "<br>";
echo $hari[2];







?>