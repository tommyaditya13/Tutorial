<?php 
function luas_dua_kubus($a, $b) {
	return $a * $a * $a + $b * $b * $b;
}

echo luas_dua_kubus(9,4) + luas_dua_kubus(20,10);

?>