<?php 
// konstanta
// define ("SALAM", "Assalamualaikum");
// echo SALAM;

// variabel
// $salam = "Assalamualaikum";
// echo $salam;

// Operator aritmatika
// echo 3 + 4 * 2;

// Operator Perbandingan
$x = "Sandhika";
$x .= "Galih";
// echo $x;
// var_dump($x);

// $mhs = ["sandhika", 10, false];
// var_dump($mhs);

// Pengulangan
// for ($i=1; $i <= 100; $i++) { 
	
// 	for ($j=1; $j <= $i; $j++) { 
// 		echo $i;
// 	}
// 	echo "<br>";

// }
// echo "selesai";


// Pengkondisian
// $x = 13;
// if ($x % 2 == 0) {
// 	echo "$x adalah bilangan GENAP!";
// 	echo "<br>";
// } else {
// 	echo "$x adalah bilangan GANJIL";
// 	echo "<br>";
// }
// echo "selesai!";

// $x = 13;
// $bil = ( $x % 2 == 0 ) ? "GENAP" : "GANJIL";
// echo "$x adalah bilangan $bil";

// for ($i=1; $i <= 100; $i++) { 
// 	if( $i % 2 == 0 ) {
// 		echo "$i ";
// 	}
// }
























 ?>