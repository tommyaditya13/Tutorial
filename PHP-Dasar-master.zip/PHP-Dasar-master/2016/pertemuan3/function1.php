<?php
// UNIX timestamp 
// echo time();
// echo "<br>";

// // date
// // l = hari, j = tanggal, F = bulan, Y = tahun
// echo date("l, j F Y", time()+60*60*24*360);
// echo "<br>";

// //mktime
// echo mktime(0,0,0,25,8,1985);

// STRING
// strlen(string) 
// $nama = "Sandhika Galih";
// echo strlen($nama);

// strcmp(text1, text2) string compare
// $text1 = "Sandhika";
// $text2 = "Galih";
// echo strcmp($text1, $text2);

//str_replace
$text = "Pemrograman Web";
echo str_replace("Web", "<em>Web</em>", $text);












?>