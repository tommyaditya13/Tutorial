<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Coba HTML</title>
</head>
<body>
	
	<h1>Hello World</h1>

</body>
</html>