<?php 
$nama_depan = "Sandhika";
$nama_belakang = "Galih";
$umur = 30;

echo 'contoh "tulisan" oleh mahasiswa pada hari jum\'at';

echo "<br>";

echo "hari ini adalah hari jum'at";

echo "<br>";

echo "tag untuk membuat paragraf adalah &lt;p&gt;";



echo "<br>";


echo "Halo, nama saya $nama_depan $nama_belakang";
echo "<br><br>";
echo "isi dari variabel \$umur = $umur";
echo "<br>";
echo "Umur saya $umur tahun";
echo "<br>";
echo "Nama Lengkap Saya " . $nama_depan . " " . $nama_belakang;
echo "<br>";
echo "25 tahun lagi, umur saya " . ($umur + 25) . " tahun";











?>