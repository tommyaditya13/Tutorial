<?php 
	$nama_depan = "Sandhika";
	$nama_belakang = "Galih";
	$umur = 30;
?>
<!DOCTYPE html>
<html>
<head>
	<title>Coba PHP</title>
</head>
<body>

	<h1>Halo, Nama Saya <?php echo $nama_depan; ?> <?php echo $nama_belakang; ?></h1>
	<h3>Umur saya <?php echo $umur; ?> tahun.</h3>
	
</body>
</html>