<!doctype html>
<html>
<head>
	<title><?php echo $judul_halaman; ?></title>
	<link rel="stylesheet" href="../css/gumby.css">
	<link rel="stylesheet" href="../css/font.css">
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>