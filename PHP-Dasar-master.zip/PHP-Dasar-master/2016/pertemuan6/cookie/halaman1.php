<?php 
setcookie("nama", "Sandhika", time() + 30);

?>