<?php 
session_start();

$_SESSION["nama"] = "Sandhika";

?>