<?php 
// Variabel Super Global
// tipenya adalah Associative Array
// $_SERVER
// $_GET
// $_POST
// $_SESSION
// $_COOKIE

// echo "<pre>";
// 	print_r($_SERVER);
// echo "</pre>";
// echo $_SERVER["DOCUMENT_ROOT"];

// $_GET
// Request Method-nya : get
// bisa diisi melalui URL
echo "<pre>";
	print_r($_GET);
echo "</pre>";

echo $_GET["email"];





?>