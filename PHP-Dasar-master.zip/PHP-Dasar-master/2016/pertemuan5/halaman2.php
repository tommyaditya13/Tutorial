<?php 
echo $nama;
?>