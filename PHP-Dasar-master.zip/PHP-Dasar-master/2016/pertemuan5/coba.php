<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Coba</title>
</head>
<body>
<?php 
echo "<pre>";
echo "halo   
	apa

	kabar";
echo "</pre>";
?>
</body>
</html>