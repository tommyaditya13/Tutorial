<?php 
    
    // ini adalah komentar untuk satu baris
    
    /*

		ini
		adalah
		komentar
		untuk
		beberapa baris

    */ 

	echo "Komentar pada PHP";
?>