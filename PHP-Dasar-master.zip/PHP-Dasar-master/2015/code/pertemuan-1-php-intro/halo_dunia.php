<?php 
    echo "Halo dunia!!"; 	
    print "<br>";
    echo "Halo Lagi!";
    print"<hr>";
?>