<?php

    echo "Hello \"Sandhika\"";  
?>