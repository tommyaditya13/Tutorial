<?php 
/*	WARNING:  JANGAN PERNAH include file ini saat website sudah diluncurkan
	file ini sangat berguna pada saat development karena menampilkan informasi TERLALU BANYAK
	informasi yang ditampilkan terkait dengan sistem dari server tempat kita menyimpan aplikasi
	informasi ini bisa saja digunakan untuk kejahatan
*/
	phpinfo(); 
?>