<?php 
// jalankan fungsi session_start(); untuk memulai session
// jalankan sebelum ada elemen HTML apapun
session_start();

// akses ke variabel superglobal $_SESSION
// mengisikan pasangan key dan value
$_SESSION["nama"] = "Sandhika"; 
?>