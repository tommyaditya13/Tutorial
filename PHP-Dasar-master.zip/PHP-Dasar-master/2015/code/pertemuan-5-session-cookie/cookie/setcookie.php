<?php 
// setcookie("name", "value", "expired", "path", "domain", "secure")
// set cookie selama 1 hari / 24 jam
setcookie("nama", "sandhika", time() + 60 * 60 * 24, "/pw2/pertemuan-5a/"); 
?>