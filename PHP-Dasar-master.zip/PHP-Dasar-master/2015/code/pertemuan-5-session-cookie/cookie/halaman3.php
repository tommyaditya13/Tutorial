<!doctype html>
<html>
<head>
	<title>Halaman 3</title>
</head>
<body>

	<h1>Selamat Datang, <?= $_COOKIE["nama"]; ?></h1>

</body>
</html>