<?php
// cetak isi dari cookie nama
// yang sudah di-set sebelumnya
echo $_COOKIE["nama"];
?>

