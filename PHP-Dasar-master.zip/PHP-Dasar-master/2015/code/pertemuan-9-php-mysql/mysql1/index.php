<?php
require 'functions.php';
$conn = koneksi();

require 'index.view.php';

?>