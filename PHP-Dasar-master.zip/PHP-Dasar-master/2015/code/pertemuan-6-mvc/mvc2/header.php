<!doctype html>
<html>
<head>
	<title><?= $judul; ?> | Pemrograman Web II</title>
	<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="wrapper">

  <div class="header">
     <h1>My Website</h1>
  </div>

  <div class="content">
    <h3>Halaman <?= $judul; ?></h3>