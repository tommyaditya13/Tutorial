<?php 
 
function render_header($judul = "") {
	require "header.php";
}



?>