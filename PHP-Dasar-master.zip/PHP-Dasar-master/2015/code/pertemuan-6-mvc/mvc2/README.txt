mvc/2/README

Sandhika Galih
sandhikagalih@unpas.ac.id
Pemrograman Web II 20132014

* menampilkan 5 halaman HTML statis
* menambahkan halaman footer dan sidebar yang di require di tiap-tiap halaman utama
* menambahkan halaman functions.php yang berisi semua fungsi-fungsi yang dibutuhkan
* halaman functions.php di require di tiap-tiap halaman 
* mengganti pemanggilan require header di tiap-tiap halaman dengan fungsi render_header()
* render_header() berfungsi memanggil halaman header dengan judul halaman yang berbeda untuk tiap halaman yang memanggilnya


css/
images/
index.php
products.php
services.php
contact.php
about.php
header.php - header untuk semua halaman
footer.php - footer untuk semua halaman
sidebar.php - sidebar untuk semua halaman
functions.php - halaman yang berisi fungsi-fungsi yang dibutuhkan