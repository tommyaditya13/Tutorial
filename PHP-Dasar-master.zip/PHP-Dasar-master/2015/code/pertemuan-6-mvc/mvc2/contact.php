<?php require "functions.php"; ?>

<?php render_header("Contact"); ?>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita, velit porro suscipit doloremque laudantium deleniti adipisci at. Nam, cupiditate qui tenetur eveniet labore veniam officia inventore autem adipisci sapiente culpa quaerat. </p>
  </div>

<?php require "sidebar.php"; ?>

<?php require "footer.php"; ?>