<?php require "header.php"; ?>

  <div class="content">
    <h3>Halaman Home</h3>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti, nobis, obcaecati, ducimus, asperiores placeat amet quidem a voluptate eos et voluptatem molestias perspiciatis quasi incidunt eius necessitatibus quibusdam accusamus minus?</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita, velit porro suscipit doloremque laudantium deleniti adipisci at. Nam, cupiditate qui tenetur eveniet labore veniam officia inventore autem adipisci sapiente culpa quaerat. Beatae, aperiam, rerum, quasi animi possimus incidunt fugiat quos doloremque eum minima illum at nemo rem veniam corrupti consequuntur nostrum! Assumenda, nisi, laborum, dolor, quos alias tempore culpa iure corporis id cum velit nobis eligendi autem hic doloremque obcaecati iusto repudiandae odio commodi recusandae ab ullam amet eaque laudantium sequi libero sit omnis. Eos, quis, nam, cupiditate veniam soluta illum laudantium voluptas blanditiis ullam laborum unde rem repellendus sunt!</p>
  </div>

<?php require "sidebar.php"; ?>

<?php require "footer.php"; ?>

