<!doctype html>
<html>
<head>
	<title>Home | Pemrograman Web II</title>
	<link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="wrapper">

  <div class="header">
     <h1>My Website</h1>
  </div>