mvc/1/README

Sandhika Galih
sandhikagalih@unpas.ac.id
Pemrograman Web II 20132014

* menampilkan 5 halaman HTML statis
* menambahkan halaman header, footer dan sidebar yang di require di tiap-tiap halaman utama

css/
images/
index.php
products.php
services.php
contact.php
about.php
header.php - header untuk semua halaman
footer.php - footer untuk semua halaman
sidebar.php - sidebar untuk semua halaman