  <div class="clear"></div>	

  <div class="footer">
    <p>Copyright &copy;2009. 
      Dibuat oleh <a href="http://sandhikagalih.net/" title="SandhikaGalih.net">Sandhika Galih</a></p>
  </div>  

</div>

</body>
</html>