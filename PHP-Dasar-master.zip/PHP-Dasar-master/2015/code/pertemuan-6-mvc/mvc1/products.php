<?php require "header.php"; ?>

  <div class="content">
    <h3>Halaman Product</h3>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita, velit porro suscipit doloremque laudantium deleniti adipisci at. Nam, cupiditate qui tenetur eveniet labore veniam officia inventore autem adipisci sapiente culpa quaerat.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic, alias ducimus sapiente soluta ipsa maiores nesciunt tenetur. Eius, excepturi, quidem, molestiae in blanditiis quisquam commodi laborum distinctio nesciunt voluptatum illum hic quaerat quasi ullam cumque architecto rem molestias odit quo voluptatibus. Harum, magni excepturi recusandae soluta similique quasi qui assumenda quae repellat ab! Ea, et necessitatibus officiis facere sequi aliquid quod non odio voluptatum nostrum laudantium qui ipsa maxime fugiat ab dicta vel sint sapiente modi commodi. Doloremque, deserunt, non?</p>
  </div>

<?php require "sidebar.php"; ?>

<?php require "footer.php"; ?>