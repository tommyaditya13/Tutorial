<?php require "functions.php"; ?>

<?php render_header("Services"); ?>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita, velit porro suscipit doloremque laudantium deleniti adipisci at.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Similique delectus omnis aut necessitatibus molestiae non dolorum repellat ipsa quibusdam blanditiis. Corporis nihil incidunt natus accusamus blanditiis possimus nesciunt adipisci illum.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veritatis, autem, quod omnis ullam officiis aut. Adipisci, perferendis asperiores consequuntur sed.</p>
  </div>

<?php render_sidebar("Services"); ?>

<?php require "footer.php"; ?>