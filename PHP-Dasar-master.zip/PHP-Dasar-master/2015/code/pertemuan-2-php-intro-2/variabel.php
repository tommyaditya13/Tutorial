<?php 
    /*
		VARIABEL pada PHP

		diawali dengan tanda $
		nama variabel boleh diawali '_' atau 'huruf'
		nama variabel boleh mengandung angka, tapi tidak boleh diawali angka
    */ 


	$x = 5;
	$y = 6;
	$z = $x + $y;

	echo $z;
?>