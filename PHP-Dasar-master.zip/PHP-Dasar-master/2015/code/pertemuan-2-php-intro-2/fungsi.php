<?php 
    /*
	FUNCTION

		function nama_fungsi(parameter1, parameter2)
		{
			.. kode yang dieksekusi ..
		}

		nama_fungsi();
    */

    function panggil_nama($nama)
    {
    	return $nama;
    } 

    panggil_nama("Sandhika");
?>