<?php 
/*
ARRAY
Deklarasi & cara pakai
:: array adalah sebuah tipe data yang berisi pasangan key dan value
array memiliki index yang dimulai dari 0

ket: hilangkan komentar pada blok skrip yang dibutuhkan untuk menjalankan skrip tsb	
*/ 


// Deklarasi Array
// cara 1
$buah = array("jeruk", "pisang", "strawberry", "mangga");

// cara 2 - hanya untuk PHP versi 5.4.x ke atas
$sayur = ["bayam", "kangkung", "tomat", "timun"];

// ---
// echo "Penulisan array 1: <br>";
// echo "\$buah = array(\"jeruk\", \"pisang\", \"strawberry\", \"mangga\");";
// echo "<br><br>";

// echo "Penulisan array 2: <br>";
// echo "\$sayur = [\"bayam\", \"kangkung\", \"tomat\", \"timun\"];";
// echo "<br><br>";	
// ---

?>