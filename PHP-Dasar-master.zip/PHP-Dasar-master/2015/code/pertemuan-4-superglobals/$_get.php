<!doctype html>
<html>
<head>
	<title>$_GET</title>
</head>	
<body>

<form action="search.php" method="get">
	<label for="keyword">Keyword</label>
	<input type="text" name="keyword" id="keyword">
		<br>
	<input type="submit" value="submit">
</form>

</body>
</html>