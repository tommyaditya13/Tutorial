<? 
/**
 * home.php
 *
 * Halaman home sederhana ketika berhasil login.
 *
 * Sandhika Galih
 * sandhikagalih@unpas.ac.id
 */
?>

<!doctype html>
<html>
  <head>
    <title>Home</title>
  </head>
  <body>
    <h1>Home</h1>
    <h3>Selamat Datang, Anda Telah Login.</h3>
    <h4><a href="login0.php">Logout</a></h4>
  </body>
</html>
