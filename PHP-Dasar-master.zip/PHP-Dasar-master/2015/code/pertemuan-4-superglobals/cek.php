<!doctype html>
<html>
<head>
	<title>Cek Gender</title>
</head>
<body>

<h3>Selamat datang  <?php echo $_POST['gender'] . " " . $_POST['nama']; ?></h3>

</body>
</html>

