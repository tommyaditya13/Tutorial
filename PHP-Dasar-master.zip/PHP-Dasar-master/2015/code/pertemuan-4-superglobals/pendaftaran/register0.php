<?
/***************************************************************
 * register0.php
 *
 * Sandhika Galih
 * sandhikagalih@unpas.ac.id
 *
 * Menampilkan isi dari $_POST.
 ***************************************************************/

?>

<!doctype html>

<html>
  <head>
    <title>Asisten</title>
  </head>
  <body>
    <pre>
      <? print_r($_POST); ?>
    </pre>
  </body>
</html>