<!doctype html>
<html>
<head>
	<title>Search</title>
</head>
<body>

<h3>Keyword yang dimasukkan: <?php echo $_GET["keyword"]; ?></h3>

</body>
</html>