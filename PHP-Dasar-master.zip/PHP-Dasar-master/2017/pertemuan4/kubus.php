<?php 

function volume_dua_kubus($a, $b) {
	return $a * $a * $a + $b * $b * $b;
}

echo volume_dua_kubus(9,4);









?>