<?php
// date()
// echo date('l, j F Y');
// echo "<br>";
// echo "Sekarang pukul " . date('G:i');

// time()
// UNIX Timestamp
// detik yang sudah berlalu sejak 1 januari 1970
// echo time() - 3600;

// echo date('l', time() - 60 * 60 * 24 * 100);

// mktime()
// make time, membuat waktu
// jam, menit, detik, bulan, tanggal, tahun
// echo mktime(0,0,0,2,28,2017);
// echo "<br>";
// echo date('l', mktime(0,0,0,3,17,1998));

// strtotime()
// echo mktime(0,0,0,2,28,2017);
// echo "<br>";
// echo strtotime('28 Feb 2017');
$x = "";
echo empty($x);




?>