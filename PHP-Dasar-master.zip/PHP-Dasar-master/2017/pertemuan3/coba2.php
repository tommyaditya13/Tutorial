<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

<p>
	tag &lt;h1&gt;&lt;/h1&gt; digunakan untuk membuat heading
</p>
	
</body>
</html>