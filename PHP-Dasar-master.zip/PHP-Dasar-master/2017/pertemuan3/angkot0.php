<?php 
$jml_angkot = 10;
$no_angkot = 1;

while( $no_angkot <= $jml_angkot ) {
	echo "Angkot No. $no_angkot beroperasi dengan baik. <br>";
$no_angkot++;
}

?>