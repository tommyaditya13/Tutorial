<?php 
// Pengulangan
// While
$nilai_awal = 1;
$nilai_akhir = 100;
while( $nilai_awal <= $nilai_akhir ) {
	echo "Hello World $nilai_awal x<br>";
$nilai_awal++;
}


?>