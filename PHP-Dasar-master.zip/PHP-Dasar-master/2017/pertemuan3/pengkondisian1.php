<?php 
$x = 500;
if( $x < 100 ) {
	echo "$x lebih kecil dari 100 <br>";
} else if( $x === 500 ) {
	echo "nilai yang dimasukkan adalah 500<br>";
} else {
	echo "$x lebih besar dari 100 <br>";
}
echo "Selesai";
?>