<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Coba Post</title>
</head>
<body>
	
	<form action="halaman1.php" method="post">
		<label for="nama">Masukkan Nama : </label>
		<input type="text" id="nama" name="nama" autofocus>
		<br>
		<label for="email">Masukkan Email : </label>
		<input type="text" id="email" name="email">
		<br>
		<button type="submit" name="submit">Kirim!</button>
	</form>

</body>
</html>