<?php 
// ARRAY
// mendeklarasikan Array / membuat Array
$mahasiswa = ["sandhika", "galih", "tri"];
$hari = array("senin", "selasa", "rabu");
$array = [12, true, "teks"];

// menampilkan isi array (untuk debugging)
// var_dump(array) | print_r(array)
// var_dump($mahasiswa);
// print_r($hari);

// manipulasi array
// var_dump($mahasiswa);
// $mahasiswa[] = "fajar";
// $mahasiswa[] = "erik";
// var_dump($mahasiswa);

// menghitung isi array
// count(array)
echo count($mahasiswa);





?>